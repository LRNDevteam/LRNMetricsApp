/* Production / LIS / Collection Insights panel. Reads #riRoot data-* and
   talks to NotesController. Screen 5 Active Note Detail matches the client
   View/Edit mockup (context, audit, revision history, archive). */
(function () {
    "use strict";
    const root = document.getElementById("riRoot");
    if (!root) return;
    // Embedded report (Executive Summary highlights): insights are shown open, without row actions.
    const readOnly = root.dataset.readonly === "1";
    // A saved snapshot: the week's insights as captured (data-snapshot-url, empty when none were), never the
    // live Notes API, and nothing can be added, edited or deleted.
    const snapshot = root.dataset.snapshot === "1";
    const snapshotUrl = root.dataset.snapshotUrl || "";

    function parseWeekRange(text) {
        const out = { start: "", end: "" };
        if (!text) return out;
        const toIso = s => {
            s = String(s || "").trim();
            let m = s.match(/^(\d{1,2})[.\/](\d{1,2})[.\/](\d{4})$/);
            if (m) return `${m[3]}-${m[1].padStart(2, "0")}-${m[2].padStart(2, "0")}`;
            m = s.match(/^(\d{1,2})[.\/](\d{1,2})[.\/](\d{2})$/);
            if (m) {
                const yy = parseInt(m[3], 10);
                const year = yy >= 70 ? 1900 + yy : 2000 + yy;
                return `${year}-${m[1].padStart(2, "0")}-${m[2].padStart(2, "0")}`;
            }
            m = s.match(/^(\d{4})[-.\/](\d{1,2})[-.\/](\d{1,2})$/);
            if (m) return `${m[1]}-${m[2].padStart(2, "0")}-${m[3].padStart(2, "0")}`;
            const d = new Date(s);
            return isNaN(d) ? "" : d.toISOString().slice(0, 10);
        };
        const tokens = String(text).match(/\d{4}-\d{1,2}-\d{1,2}|\d{1,2}[.\/]\d{1,2}[.\/]\d{2,4}/g) || [];
        if (tokens.length >= 2) {
            out.start = toIso(tokens[0]);
            out.end = toIso(tokens[tokens.length - 1]);
            return out;
        }
        if (tokens.length === 1) {
            out.start = out.end = toIso(tokens[0]);
            return out;
        }
        const parts = String(text).split(/\s+[-–—]\s+|\s+to\s+/i).filter(Boolean);
        if (parts.length >= 2) { out.start = toIso(parts[0]); out.end = toIso(parts[1]); }
        else if (parts.length === 1) out.start = out.end = toIso(parts[0]);
        return out;
    }

    const wk = parseWeekRange(root.dataset.weekText || "");
    const ctx = {
        lab: root.dataset.lab || "",
        reportName: root.dataset.reportName || "Production Report",
        runId: root.dataset.runId || "",
        weekText: root.dataset.weekText || "",
        weekStart: root.dataset.weekStart || wk.start || "",
        weekEnd: root.dataset.weekEnd || wk.end || wk.start || "",
        token: (root.querySelector('input[name="__RequestVerificationToken"]') || {}).value || ""
    };
    const apiBase = (root.dataset.base || "/").replace(/\/$/, "");
    const q = obj => Object.entries(obj).filter(([, v]) => v != null && v !== "").map(([k, v]) => encodeURIComponent(k) + "=" + encodeURIComponent(v)).join("&");
    const esc = s => (s == null ? "" : String(s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c])));
    const isoDate = s => { if (!s) return ""; const d = new Date(s); return isNaN(d) ? "" : d.toISOString().slice(0, 10); };
    const ymd = s => {
        if (!s) return "";
        const m = String(s).match(/^(\d{4})-(\d{2})-(\d{2})/);
        if (m) return `${m[1]}-${m[2]}-${m[3]}`;
        const d = new Date(s);
        return isNaN(d) ? "" : `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
    };
    const weekTextFrom = (start, end) => {
        const fmt = v => { const m = String(v || "").match(/^(\d{4})-(\d{2})-(\d{2})$/); return m ? `${m[2]}.${m[3]}.${m[1]}` : ""; };
        const s = fmt(start), e = fmt(end || start);
        if (!s) return "";
        return !e || s === e ? s : `${s} - ${e}`;
    };
    const MONTHS = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
    const fmtShort = s => {
        if (!s) return "";
        const d = new Date(s);
        if (isNaN(d)) return "";
        return d.getDate() + "-" + MONTHS[d.getMonth()];
    };
    const fmtDT = s => { if (!s) return ""; const d = new Date(s); return isNaN(d) ? "" : d.toLocaleString(); };
    const stripHtml = s => { if (!s) return ""; const d = document.createElement("div"); d.innerHTML = s; return (d.textContent || d.innerText || "").trim(); };
    const htmlFromText = s => {
        if (!s) return "";
        if (/<[a-z][\s\S]*>/i.test(s)) return s;
        return esc(s).replace(/\n/g, "<br>");
    };
    function sanitizeRichHtml(s) {
        if (!s) return "";
        if (!/<[a-z][\s\S]*>/i.test(s)) return esc(s).replace(/\n/g, "<br>");
        const wrap = document.createElement("div");
        wrap.innerHTML = s;
        wrap.querySelectorAll("script,iframe,object,embed,link,meta,form").forEach(el => el.remove());
        wrap.querySelectorAll("*").forEach(el => {
            [...el.attributes].forEach(a => {
                const n = a.name.toLowerCase();
                if (n.startsWith("on") || n === "src" || n === "srcset") el.removeAttribute(a.name);
                if (n === "href") {
                    const v = String(a.value || "").trim();
                    if (!/^(https?:|mailto:|#)/i.test(v)) el.removeAttribute(a.name);
                }
            });
            if (el.getAttribute("style")) {
                el.setAttribute("style", String(el.getAttribute("style")).replace(/expression|url\s*\(|javascript/gi, ""));
            }
        });
        return wrap.innerHTML;
    }

    function reportLayout() {
        const r = (ctx.reportName || "").toLowerCase();
        const base = r.includes("collection")
            ? {
                risk: "Risk", party: "Responsible Party", insights: "Insights",
                claims: "# of Cases", charge: "Total Billed",
                action: "Action / Solution / Suggestion", feedback: "Feedback / Response",
                owner: "Response By", discuss: "Discussion Date", eta: "ETA",
                closed: "Closed Date", status: "Status",
                footer: "Previously Analysed Data - Pending Items",
                footerSub: "(Refer Old Reports for Data Links)"
            }
            : r.includes("lis")
            ? {
                risk: "Risk", party: "Responsible Party", insights: "Insights",
                claims: "# of Claims", charge: "Expected Reimbursement ($)",
                action: "Action / Solution / Suggestions", feedback: "Feedback / Response",
                owner: "Responsibility", discuss: "Discussion Date", eta: "ETA",
                closed: "Closed Date", status: "Status",
                footer: "Previously Analyzed Data - All Data",
                footerSub: "(Refer Old Reports for Data Links)"
            }
            : {
                risk: "Risk", party: "Responsible Party", insights: "Insights",
                claims: "# of Claims", charge: "Total Charge",
                action: "Action / Solution / Suggestions", feedback: "Feedback / Response",
                owner: "Responsibility", discuss: "Discussion Date", eta: "ETA",
                closed: "Closed Date", status: "Status",
                footer: "Previously Analysed Data - Pending Items",
                footerSub: "(Refer Old Reports for Data Links)"
            };
        const nameFor = key => {
            const cols = tplColumns();
            const hit = cols.find(c => String(fieldKey(c)).toLowerCase() === String(key).toLowerCase());
            const n = hit && String(colName(hit) || "").trim();
            return n || "";
        };
        return {
            risk: nameFor("Risk") || base.risk,
            party: nameFor("ResponsibleParty") || base.party,
            insights: nameFor("Insights") || base.insights,
            claims: nameFor("NoOfClaims") || base.claims,
            charge: nameFor("TotalCharge") || base.charge,
            action: nameFor("ActionSolution") || base.action,
            feedback: nameFor("FeedbackResponse") || base.feedback,
            owner: nameFor("Responsibility") || base.owner,
            discuss: nameFor("DiscussionDate") || base.discuss,
            eta: nameFor("ETA") || base.eta,
            closed: nameFor("ClosedDate") || base.closed,
            status: nameFor("Status") || base.status,
            footer: base.footer,
            footerSub: base.footerSub
        };
    }

    const el = {
        body: document.getElementById("riBody"),
        alert: document.getElementById("riAlert"),
        tpl: document.getElementById("riTemplate"),
        add: document.getElementById("riAddBtn"),
        archiveBtn: document.getElementById("riArchiveBtn"),
        form: document.getElementById("riForm"),
        save: document.getElementById("riSaveBtn"),
        historyBtn: document.getElementById("riHistoryBtn"),
        title: document.getElementById("riModalTitle"),
        sub: document.getElementById("riModalSub"),
        versionNote: document.getElementById("riVersionNote"),
        riskBadge: document.getElementById("riRiskBadge"),
        statusBadge: document.getElementById("riStatusBadge"),
        activeBadge: document.getElementById("riActiveBadge"),
        historyTimeline: document.getElementById("riHistoryTimeline"),
        historySummary: document.getElementById("riHistorySummary"),
        historyNoteBadge: document.getElementById("riHistoryNoteBadge"),
        archiveBody: document.getElementById("riArchiveBody"),
        expandBtn: document.getElementById("riExpandBtn"),
        expandBody: document.getElementById("riExpandBody"),
        floatWin: document.getElementById("riFloat"),
        minimizeBtn: document.getElementById("riMinimizeBtn"),
        deleteRiskBadge: document.getElementById("riDeleteRiskBadge"),
        deleteStatusBadge: document.getElementById("riDeleteStatusBadge"),
        deleteEntry: document.getElementById("riDeleteEntry"),
        deleteInsightPreview: document.getElementById("riDeleteInsightPreview"),
        deleteConfirmBtn: document.getElementById("riDeleteConfirmBtn")
    };

    let lookups = { risks: [], statuses: [], responsibleParties: [] };
    let templates = [];
    let selectedTpl = null;
    let rows = [];
    let editing = null;
    let detailReadOnly = false;
    let dirty = false;
    let modal = null;
    let historyModal = null;
    let archiveModal = null;
    let deleteModal = null;
    let pendingDeleteId = null;

    function showAlert(msg, kind) {
        if (!el.alert) return;
        el.alert.hidden = !msg;
        el.alert.className = "itm-alert " + (kind || "info");
        el.alert.textContent = msg || "";
    }

    async function api(path, opts) {
        const res = await fetch(path, opts);
        if (!res.ok) {
            let msg = "Request failed (" + res.status + ")";
            try { const j = await res.json(); if (j && j.error) msg = j.error; } catch { /* ignore */ }
            throw new Error(msg);
        }
        return res.status === 204 ? null : res.json();
    }
    const getJson = path => api(path, { headers: { Accept: "application/json" } });
    const postJson = (path, body) => api(path, {
        method: "POST",
        headers: { "Content-Type": "application/json", Accept: "application/json", RequestVerificationToken: ctx.token },
        body: body ? JSON.stringify(body) : null
    });

    function tplColumns() {
        const t = selectedTpl || {};
        return t.columns || t.Columns || [];
    }
    function colName(col) {
        return (col && (col.columnName || col.ColumnName)) || "";
    }
    function fieldKey(col) {
        const k = String((col && (col.fieldKey || col.FieldKey)) || "").trim();
        if (k) return k;
        const n = String(colName(col) || "").toLowerCase();
        if (n === "risk") return "Risk";
        if (n.includes("responsible party")) return "ResponsibleParty";
        if (n === "insights") return "Insights";
        if (n.includes("link") || n === "data") return "DataLink";
        if (n.includes("claim") || n.includes("sample") || n.includes("case")) return "NoOfClaims";
        if (n.includes("charge") || n.includes("bill") || n.includes("reimbursement") || n.includes("balance")) return "TotalCharge";
        if (n.includes("action")) return "ActionSolution";
        if (n.includes("feedback")) return "FeedbackResponse";
        if (n.includes("response by") || n === "responsibility") return "Responsibility";
        if (n.includes("discussion")) return "DiscussionDate";
        if (n === "eta") return "ETA";
        if (n.includes("closed")) return "ClosedDate";
        if (n === "status") return "Status";
        return colName(col) || "Text";
    }
    // Risk, Insights and Status drive badges, validation and archiving, so they always show.
    const CORE_FIELDS = ["Risk", "Insights", "Status"];
    function hasField(key) {
        const cols = tplColumns();
        if (!cols.length || CORE_FIELDS.includes(key)) return true;
        const k = key.toLowerCase();
        return cols.some(c => String(fieldKey(c)).toLowerCase() === k);
    }

    function riskCode(val) {
        const v = String(val || "").toLowerCase();
        if (v.startsWith("high") || v === "red") return "Red";
        if (v.startsWith("low") || v === "green") return "Green";
        return "Yellow";
    }
    function riskDisplay(n) {
        const label = (n.riskLabel || "").toLowerCase();
        if (label.startsWith("high")) return "High";
        if (label.startsWith("low")) return "Low";
        if (label.startsWith("medium")) return "Medium";
        if (n.riskCode === "Red") return "High";
        if (n.riskCode === "Green") return "Low";
        return "Medium";
    }
    function riskSelectValue(n) {
        if (!n) return "Red";
        return n.riskCode || riskCode(riskDisplay(n));
    }
    function statusCode(val) {
        const v = String(val || "").toLowerCase();
        if (v.includes("yet to discuss") || v === "discuss") return "Discuss";
        if (v.includes("progress") || v === "wip") return "WIP";
        if (v.includes("defer")) return "Deferred";
        if (v.includes("close")) return "Closed";
        const hit = (lookups.statuses || []).find(s => s.label.toLowerCase() === v || s.code.toLowerCase() === v);
        return hit ? hit.code : (val || "Open");
    }
    function statusCss(code) {
        const c = statusCode(code);
        if (c === "Closed") return "status-Closed";
        if (c === "WIP") return "status-WIP";
        if (c === "Deferred") return "status-Deferred";
        if (c === "Discuss") return "status-Discuss";
        return "status-Open";
    }

    function money(v) {
        if (v == null || v === "") return "";
        const n = Number(v);
        if (isNaN(n)) return esc(v);
        if (n === 0) return "$ -";
        const abs = Math.abs(n).toLocaleString(undefined, { maximumFractionDigits: 0 });
        return n < 0 ? "$ (" + abs + ")" : "$ " + abs;
    }

    function parseClaims(v) {
        if (v == null || v === "") return null;
        const n = parseInt(String(v).replace(/,/g, "").replace(/\s/g, ""), 10);
        return Number.isFinite(n) ? n : null;
    }
    function formatClaims(v) {
        const n = typeof v === "number" ? v : parseClaims(v);
        return n == null ? "" : n.toLocaleString("en-US");
    }
    function bindClaimsInput(input) {
        if (!input) return;
        const apply = () => { input.value = formatClaims(input.value); };
        input.addEventListener("blur", apply);
        input.addEventListener("change", apply);
    }

    function partyOptions(sel) {
        const list = lookups.responsibleParties || [];
        let found = false;
        let opts = `<option value="">— Select —</option>` + list.map(p => {
            if (p === sel) found = true;
            return `<option value="${esc(p)}" ${p === sel ? "selected" : ""}>${esc(p)}</option>`;
        }).join("");
        if (sel && !found) opts += `<option value="${esc(sel)}" selected>${esc(sel)}</option>`;
        return opts;
    }
    function riskOptions(sel) {
        const opts = (lookups.risks || []).length
            ? lookups.risks.map(r => ({ value: r.code, label: r.code + (r.label ? " — " + r.label : "") }))
            : [{ value: "Red", label: "Red — High" }, { value: "Yellow", label: "Yellow — Medium" }, { value: "Green", label: "Green — Low" }];
        return opts.map(o => `<option value="${esc(o.value)}" ${o.value === sel ? "selected" : ""}>${esc(o.label)}</option>`).join("");
    }
    function statusOptions(sel) {
        const opts = (lookups.statuses || []).length
            ? lookups.statuses
            : [{ code: "Discuss", label: "Yet to Discuss" }, { code: "Open", label: "Open" }, { code: "WIP", label: "In Progress" }, { code: "Deferred", label: "Deferred" }, { code: "Closed", label: "Closed" }];
        return opts.map(s => `<option value="${esc(s.code)}" ${s.code === sel ? "selected" : ""}>${esc(s.label || s.code)}</option>`).join("");
    }

    function bindRowActs(container) {
        if (!container) return;
        container.querySelectorAll("[data-view]").forEach(btn => {
            btn.onclick = () => openDetail(rows.find(r => String(r.noteId) === btn.getAttribute("data-view")), false);
        });
        container.querySelectorAll("[data-hist]").forEach(btn => {
            btn.onclick = () => openHistory(+btn.getAttribute("data-hist"));
        });
        container.querySelectorAll("[data-del]").forEach(btn => {
            btn.onclick = () => deleteNote(+btn.getAttribute("data-del"));
        });
    }

    function openDeleteConfirm(noteId) {
        if (!noteId) return;
        const row = rows.find(r => Number(r.noteId) === Number(noteId));
        if (row && row.archiveStatus === "Archived") {
            showAlert("Archived notes cannot be deleted.", "error");
            return;
        }
        pendingDeleteId = noteId;
        const risk = riskDisplay(row || {});
        const riskCodeVal = (row && row.riskCode) || (risk === "High" ? "Red" : risk === "Low" ? "Green" : "Yellow");
        const st = (row && (row.statusLabel || row.statusCode)) || "—";
        if (el.deleteRiskBadge) {
            el.deleteRiskBadge.textContent = risk || "Risk";
            el.deleteRiskBadge.className = "ri-badge risk-" + riskCodeVal;
        }
        if (el.deleteStatusBadge) {
            el.deleteStatusBadge.textContent = st;
            const code = (row && row.statusCode) || "";
            el.deleteStatusBadge.className = "ri-badge status-" + (/discuss/i.test(st) || /discuss/i.test(code) ? "Discuss" : (code || "Open"));
        }
        if (el.deleteEntry) el.deleteEntry.textContent = row && row.displayNo != null ? ("#" + row.displayNo) : ("#" + noteId);
        if (el.deleteInsightPreview) {
            const text = stripHtml((row && row.insights) || "").trim();
            el.deleteInsightPreview.textContent = text || "No insight text for this row.";
        }
        if (el.deleteConfirmBtn) {
            el.deleteConfirmBtn.disabled = false;
            el.deleteConfirmBtn.innerHTML = '<i class="bi bi-trash3" aria-hidden="true"></i> Delete insight';
        }
        if (!deleteModal && window.bootstrap) {
            const node = document.getElementById("riDeleteModal");
            if (node) deleteModal = new bootstrap.Modal(node);
        }
        deleteModal && deleteModal.show();
    }

    async function confirmDeleteInsight() {
        const noteId = pendingDeleteId;
        if (!noteId) return;
        if (el.deleteConfirmBtn) {
            el.deleteConfirmBtn.disabled = true;
            el.deleteConfirmBtn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Deleting…';
        }
        try {
            await postJson(`${apiBase}/Notes/Delete?${q({ lab: ctx.lab, id: noteId })}`);
            pendingDeleteId = null;
            deleteModal && deleteModal.hide();
            showAlert("Insight deleted.", "ok");
            await loadRows();
            if (editing && Number(editing.noteId) === Number(noteId)) {
                editing = null;
                if (modal) modal.hide();
            }
        } catch (e) {
            showAlert(e.message || "Delete failed.", "error");
            if (el.deleteConfirmBtn) {
                el.deleteConfirmBtn.disabled = false;
                el.deleteConfirmBtn.innerHTML = '<i class="bi bi-trash3" aria-hidden="true"></i> Delete insight';
            }
        }
    }

    function deleteNote(noteId) {
        openDeleteConfirm(noteId);
    }

    const cls = c => (c ? ` class="${c}"` : "");

    /* Grid columns in display order, limited to the fields on the selected template. */
    function insightFields(archive) {
        const L = reportLayout();
        const long = archive ? "ri-arch-long" : "";
        const date = archive ? "ri-arch-date" : "";
        const td = (c, html) => `<td${cls(c)}>${html}</td>`;
        return [
            { key: "Risk", label: L.risk, cell: n => { const r = riskDisplay(n); return td("ri-risk-" + esc(r), esc(r)); } },
            { key: "ResponsibleParty", label: L.party, cell: n => td("", esc(n.responsibleParty || "")) },
            { key: "Insights", label: L.insights, th: archive ? long : "ri-insights",
                cell: n => td(archive ? long : "ri-insights", `<div class="ri-insights-html">${sanitizeRichHtml(n.insights || "")}</div>`) },
            { key: "NoOfClaims", label: L.claims, cell: n => td("ri-count", esc(formatClaims(n.noOfSamples))) },
            { key: "TotalCharge", label: L.charge,
                cell: n => td("ri-charge", n.totalCharge == null || n.totalCharge === "" ? "" : money(n.totalCharge)) },
            { key: "ActionSolution", label: L.action, th: archive ? long : "ri-action",
                cell: n => td(archive ? long : "ri-action-cell", esc(stripHtml(n.actionSolution || ""))) },
            { key: "FeedbackResponse", label: L.feedback, th: long, cell: n => td(long, esc(stripHtml(n.feedbackResponse || ""))) },
            { key: "Responsibility", label: L.owner, cell: n => td("", esc(n.responsibility || "")) },
            { key: "DiscussionDate", label: L.discuss, cell: n => td(date, esc(fmtShort(n.discussionDate))) },
            { key: "ETA", label: L.eta, cell: n => td(date, esc(fmtShort(n.eta))) },
            { key: "ClosedDate", label: L.closed, cell: n => td(date, esc(fmtShort(n.closedDate))) },
            { key: "Status", label: L.status, cell: n => {
                const st = n.statusLabel || n.statusCode || "";
                return td(!archive && /yet to discuss|discuss/i.test(st) ? "ri-status-discuss" : "", esc(st));
            } }
        ].filter(f => hasField(f.key));
    }

    function buildTableHtml(opts) {
        const float = !!(opts && opts.float);
        const noActs = float || readOnly;
        const L = reportLayout();
        const fields = insightFields(false);
        const colCount = fields.length + (noActs ? 1 : 2);
        const thead = `<thead><tr>
            <th>#</th>${fields.map(f => `<th${cls(f.th)}>${esc(f.label)}</th>`).join("")}${noActs ? "" : "<th></th>"}
        </tr></thead>`;
        const tfoot = float ? "" : `<tfoot><tr class="ri-foot-row"><td colspan="${colCount}"><div class="ri-footer">${esc(L.footer)}<small>${esc(L.footerSub)}</small></div></td></tr></tfoot>`;
        return `<table class="ri-table">${thead}<tbody>${rows.map(n => {
            const carry = n.archiveStatus === "Carry Forward" ? `<span class="ri-carry">Carry Forward</span>` : "";
            const canDelete = n.archiveStatus !== "Archived";
            const acts = noActs ? "" : `<td class="ri-row-acts">
                    <button type="button" class="btn btn-sm btn-outline-secondary" data-view="${n.noteId}">View</button>
                    <button type="button" class="btn btn-sm btn-outline-secondary" data-hist="${n.noteId}">History</button>
                    ${canDelete ? `<button type="button" class="btn btn-sm btn-outline-danger" data-del="${n.noteId}">Delete</button>` : ""}
                </td>`;
            return `<tr>
                <td>${esc(n.displayNo ?? "")}${carry}</td>
                ${fields.map(f => f.cell(n)).join("")}
                ${acts}
            </tr>`;
        }).join("")}</tbody>${tfoot}</table>`;
    }

    function emptyHtml() {
        return snapshot
            ? `<div class="ri-empty">No insights were saved for this week.</div>`
            : `<div class="ri-empty">No insights added for the current week range.</div>`;
    }

    function weekKey(s) {
        return String(s || "").replace(/\s+/g, " ").trim().toLowerCase();
    }

    function inCurrentWeek(n) {
        if (!ctx.weekStart && !ctx.weekText) return true;
        const hasStart = n && n.weekRangeStart != null && String(n.weekRangeStart) !== "";
        const hasText = !!(n && n.weekRangeText);
        if (!hasStart && !hasText) return true;
        if (ctx.weekStart && hasStart) {
            const raw = String(n.weekRangeStart);
            const ws = isoDate(n.weekRangeStart) || (raw.length >= 10 ? raw.slice(0, 10) : "");
            if (ws && ws === ctx.weekStart) return true;
        }
        if (ctx.weekText && hasText && weekKey(n.weekRangeText) === weekKey(ctx.weekText)) return true;
        return false;
    }

    function renderRows() {
        if (!rows.length) {
            const html = emptyHtml();
            el.body.innerHTML = html;
            if (el.expandBody) el.expandBody.innerHTML = html;
            return;
        }
        const html = buildTableHtml();
        el.body.innerHTML = html;
        bindRowActs(el.body);
        if (el.expandBody) el.expandBody.innerHTML = buildTableHtml({ float: true });
    }

    function setFloatOpen(open) {
        if (!el.floatWin) return;
        el.floatWin.classList.toggle("open", !!open);
        el.floatWin.hidden = !open;
        if (open) {
            el.expandBody.innerHTML = rows.length ? buildTableHtml({ float: true }) : emptyHtml();
            el.floatWin.style.left = "50%";
            el.floatWin.style.top = "50%";
            el.floatWin.style.right = "auto";
            el.floatWin.style.bottom = "auto";
            el.floatWin.style.width = "";
            el.floatWin.style.transform = "translate(-50%, -50%)";
        }
    }

    function setDirty(on) {
        dirty = !!on;
        if (!el.versionNote) return;
        if (detailReadOnly) {
            el.versionNote.textContent = "Archived notes are read-only.";
            return;
        }
        if (!editing) {
            el.versionNote.textContent = dirty ? "Unsaved new insight. Click Save Changes to append to the active log." : "New insight. Save to assign Entry ID and version 1.";
            return;
        }
        const ver = editing.versionNumber || 1;
        el.versionNote.textContent = dirty
            ? `Unsaved changes. Click Save Changes to create v${ver + 1}.`
            : `Current version ${ver}. Save changes to create the next revision.`;
    }

    function syncBadges() {
        const risk = el.form.querySelector("[data-key=Risk]");
        const status = el.form.querySelector("[data-key=Status]");
        const code = risk ? risk.value : (editing ? riskSelectValue(editing) : "Red");
        const st = status ? status.value : (editing ? (editing.statusCode || "Open") : "Discuss");
        const stLabel = status && status.selectedOptions[0] ? status.selectedOptions[0].text : st;
        if (el.riskBadge) {
            el.riskBadge.textContent = code || "Risk";
            el.riskBadge.className = "ri-badge risk-" + (code || "Yellow");
        }
        if (el.statusBadge) {
            el.statusBadge.textContent = stLabel || "Status";
            el.statusBadge.className = "ri-badge " + statusCss(st);
        }
        const preview = el.form.querySelector("#riRiskPreview");
        if (preview) {
            preview.textContent = code || "Risk";
            preview.className = "ri-risk-preview ri-badge risk-" + (code || "Yellow");
        }
    }

    function bindRichToolbar(ro) {
        const editor = el.form.querySelector("#riInsightsEditor");
        if (!editor || ro) return;
        try { document.execCommand("styleWithCSS", false, true); } catch { /* ignore */ }
        el.form.querySelectorAll("[data-rich]").forEach(btn => {
            btn.onclick = () => {
                editor.focus();
                const cmd = btn.getAttribute("data-rich");
                if (cmd === "bold") document.execCommand("bold");
                else if (cmd === "list") document.execCommand("insertUnorderedList");
                else if (cmd === "Red") document.execCommand("foreColor", false, "#b42318");
                else if (cmd === "Yellow") document.execCommand("foreColor", false, "#9a6500");
                else if (cmd === "Green") document.execCommand("foreColor", false, "#2f7a4d");
                setDirty(true);
            };
        });
        const risk = el.form.querySelector("[data-key=Risk]");
        if (risk) {
            risk.addEventListener("change", () => {
                const map = { Red: "#b42318", Yellow: "#9a6500", Green: "#2f7a4d" };
                editor.focus();
                document.execCommand("foreColor", false, map[risk.value] || "#9a6500");
                syncBadges();
                setDirty(true);
            });
        }
    }

    function weekFields() {
        const start = el.form.querySelector("[data-week=start]");
        const end = el.form.querySelector("[data-week=end]");
        const text = el.form.querySelector("#ri_WeekRangeText");
        return start && end ? { start, end, text } : null;
    }

    function bindWeekFields() {
        const f = weekFields();
        if (!f) return;
        const sync = () => {
            if (f.start.value && f.end.value && f.end.value < f.start.value) f.end.value = f.start.value;
            const t = weekTextFrom(f.start.value, f.end.value);
            if (f.text) f.text.value = t;
            const card = document.getElementById("riCtxWeek");
            if (card) card.textContent = t || "—";
        };
        f.start.addEventListener("change", sync);
        f.end.addEventListener("change", sync);
    }

    function openDetail(row, archived) {
        editing = row || null;
        detailReadOnly = !!archived || (row && row.archiveStatus === "Archived");
        const L = reportLayout();
        const isNew = !row;
        if (el.title) el.title.textContent = isNew ? "Add Insight" : (detailReadOnly ? "Archived Note Detail" : "Active Note Detail");
        if (el.sub) el.sub.textContent = isNew
            ? "New insight · appended to the active log on save"
            : (detailReadOnly
                ? "Read-only historical insight · current report archive"
                : "Editable active insight · authorized report users");
        if (el.activeBadge) {
            el.activeBadge.textContent = detailReadOnly ? "Archived" : "Active";
            el.activeBadge.className = "ri-badge" + (detailReadOnly ? " archived" : "");
        }
        if (el.save) el.save.hidden = detailReadOnly;
        if (el.historyBtn) el.historyBtn.hidden = isNew || detailReadOnly;

        const ro = detailReadOnly ? "disabled" : "";
        const roAttr = detailReadOnly ? "readonly" : "";
        const editable = detailReadOnly ? "false" : "true";
        const banner = detailReadOnly
            ? `<div class="ri-lock-note"><span>Archived notes are read-only. This entry cannot be edited, deleted, saved, or reopened.</span></div>`
            : `<div class="ri-edit-banner"><span>Active notes can be edited by authorized users with access to this report. Saving changes updates the active row, increments the version number, and records a revision event.</span></div>`;

        const week = (row && row.weekRangeText) || ctx.weekText || "—";
        const runId = (row && row.reportRunId) || ctx.runId || "—";
        const archiveLabel = detailReadOnly ? "Archived" : ((row && row.archiveStatus) || "Active");
        const wkStart = row ? ymd(row.weekRangeStart) : (ctx.weekStart || "");
        const wkEnd = row ? ymd(row.weekRangeEnd) : (ctx.weekEnd || ctx.weekStart || "");
        const weekSection = !weekLifecycle ? "" : `
                    <section class="ri-info-card">
                        <div class="ri-info-head"><div class="ri-info-title">Report Week Range</div><div class="ri-info-sub">Defaults to the current report week · editable</div></div>
                        <div class="ri-info-body">
                            <div class="ri-field-grid">
                                <div class="ri-field"><label for="ri_WeekRangeStart">Week Range Start</label><input id="ri_WeekRangeStart" data-week="start" type="date" value="${esc(wkStart)}" ${roAttr} /></div>
                                <div class="ri-field"><label for="ri_WeekRangeEnd">Week Range End</label><input id="ri_WeekRangeEnd" data-week="end" type="date" value="${esc(wkEnd)}" ${roAttr} /></div>
                                <div class="ri-field" style="grid-column:1 / -1;"><label for="ri_WeekRangeText">Week Range Text</label><input id="ri_WeekRangeText" readonly value="${esc(row ? (row.weekRangeText || weekTextFrom(wkStart, wkEnd)) : weekTextFrom(wkStart, wkEnd))}" /></div>
                            </div>
                        </div>
                    </section>`;
        const opt = (key, html) => (hasField(key) ? html : "");
        const actionSection = !["ActionSolution", "FeedbackResponse", "Responsibility"].some(hasField) ? "" : `
                    <section class="ri-info-card">
                        <div class="ri-info-head"><div class="ri-info-title">Action and Response</div><div class="ri-info-sub">Follow-up plan and feedback</div></div>
                        <div class="ri-info-body">
                            ${opt("ActionSolution", `<div class="ri-field" style="margin-bottom:9px;">
                                <label for="ri_ActionSolution">${esc(L.action)}</label>
                                <textarea id="ri_ActionSolution" data-key="ActionSolution" ${roAttr}>${esc(stripHtml(row ? row.actionSolution : ""))}</textarea>
                            </div>`)}
                            <div class="ri-field-grid">
                                ${opt("FeedbackResponse", `<div class="ri-field">
                                    <label for="ri_FeedbackResponse">${esc(L.feedback)}</label>
                                    <textarea id="ri_FeedbackResponse" data-key="FeedbackResponse" ${roAttr}>${esc(stripHtml(row ? row.feedbackResponse : ""))}</textarea>
                                </div>`)}
                                ${opt("Responsibility", `<div class="ri-field">
                                    <label for="ri_Responsibility">${esc(L.owner)}</label>
                                    <select id="ri_Responsibility" data-key="Responsibility" ${ro}>${partyOptions(row ? row.responsibility : "")}</select>
                                </div>`)}
                            </div>
                        </div>
                    </section>`;

        el.form.innerHTML = `
            ${banner}
            <div class="ri-ctx-row">
                <div class="ri-ctx-card"><div class="ri-ctx-label">Report Name</div><div class="ri-ctx-value">${esc(ctx.reportName)}</div></div>
                <div class="ri-ctx-card"><div class="ri-ctx-label">Week Range</div><div class="ri-ctx-value" id="riCtxWeek">${esc(week)}</div></div>
                <div class="ri-ctx-card"><div class="ri-ctx-label">Report ID / RUNID</div><div class="ri-ctx-value">${esc(runId)}</div></div>
                <div class="ri-ctx-card"><div class="ri-ctx-label">Archive Status</div><div class="ri-ctx-value">${esc(archiveLabel)}</div></div>
            </div>
            <div class="ri-detail-layout">
                <div class="ri-detail-col">
                    <section class="ri-info-card">
                        <div class="ri-info-head"><div class="ri-info-title">Insight</div><div class="ri-info-sub">Observation, risk, and impact reference</div></div>
                        <div class="ri-info-body">
                            <div class="ri-field-grid" style="margin-bottom:9px;">
                                <div class="ri-field">
                                    <label for="ri_Risk">${esc(L.risk)}</label>
                                    <select id="ri_Risk" data-key="Risk" ${ro}>${riskOptions(riskSelectValue(row))}</select>
                                    <span id="riRiskPreview" class="ri-risk-preview">Risk</span>
                                </div>
                                ${opt("ResponsibleParty", `<div class="ri-field">
                                    <label for="ri_ResponsibleParty">${esc(L.party)}</label>
                                    <select id="ri_ResponsibleParty" data-key="ResponsibleParty" ${ro}>${partyOptions(row ? row.responsibleParty : "")}</select>
                                </div>`)}
                                ${opt("NoOfClaims", `<div class="ri-field">
                                    <label for="ri_NoOfClaims">${esc(L.claims)}</label>
                                    <input id="ri_NoOfClaims" data-key="NoOfClaims" type="text" inputmode="numeric" value="${esc(formatClaims(row && row.noOfSamples))}" ${roAttr} />
                                </div>`)}
                                <div class="ri-field">
                                    <label for="ri_Status">${esc(L.status)}</label>
                                    <select id="ri_Status" data-key="Status" ${ro}>${statusOptions(row ? (row.statusCode || "Open") : "Discuss")}</select>
                                </div>
                                ${opt("TotalCharge", `<div class="ri-field">
                                    <label for="ri_TotalCharge">${esc(L.charge)}</label>
                                    <input id="ri_TotalCharge" data-key="TotalCharge" type="number" step="0.01" value="${esc(row && row.totalCharge != null ? row.totalCharge : "")}" ${roAttr} />
                                </div>`)}
                            </div>
                            <div class="ri-field">
                                <label>${esc(L.insights)}</label>
                                <div class="ri-toolbar">
                                    <button class="ri-tool" type="button" data-rich="bold" ${detailReadOnly ? "disabled" : ""}>B</button>
                                    <button class="ri-tool" type="button" data-rich="list" ${detailReadOnly ? "disabled" : ""}>• List</button>
                                    <button class="ri-tool red" type="button" data-rich="Red" ${detailReadOnly ? "disabled" : ""}>Red</button>
                                    <button class="ri-tool yellow" type="button" data-rich="Yellow" ${detailReadOnly ? "disabled" : ""}>Yellow</button>
                                    <button class="ri-tool green" type="button" data-rich="Green" ${detailReadOnly ? "disabled" : ""}>Green</button>
                                    <span class="ri-info-sub">Risk color and inline highlight stay in sync.</span>
                                </div>
                                <div id="riInsightsEditor" class="ri-rich" contenteditable="${editable}" data-key="Insights">${htmlFromText(row ? row.insights : "")}</div>
                            </div>
                        </div>
                    </section>${actionSection}
                </div>
                <div class="ri-detail-col">${weekSection}
                    <section class="ri-info-card">
                        <div class="ri-info-head"><div class="ri-info-title">Timeline</div><div class="ri-info-sub">Discussion through close</div></div>
                        <div class="ri-info-body">
                            <div class="ri-field-grid">
                                ${opt("DiscussionDate", `<div class="ri-field"><label for="ri_DiscussionDate">${esc(L.discuss)}</label><input id="ri_DiscussionDate" data-key="DiscussionDate" type="date" value="${esc(isoDate(row && row.discussionDate))}" ${roAttr} /></div>`)}
                                ${opt("ETA", `<div class="ri-field"><label for="ri_ETA">${esc(L.eta)}</label><input id="ri_ETA" data-key="ETA" type="date" value="${esc(isoDate(row && row.eta))}" ${roAttr} /></div>`)}
                                ${opt("ClosedDate", `<div class="ri-field"><label for="ri_ClosedDate">${esc(L.closed)}</label><input id="ri_ClosedDate" data-key="ClosedDate" type="date" value="${esc(isoDate(row && row.closedDate))}" ${roAttr} /></div>`)}
                                <div class="ri-field"><label>Archive Status</label><span class="ri-status-pill">${esc(archiveLabel)}</span></div>
                            </div>
                        </div>
                    </section>
                    <section class="ri-info-card">
                        <div class="ri-info-head"><div class="ri-info-title">Audit Metadata</div><div class="ri-info-sub">System-managed fields</div></div>
                        <div class="ri-info-body">
                            <div class="ri-field-grid">
                                <div class="ri-field"><label>Note / Entry ID</label><input readonly value="${esc(row ? (row.noteId || "") : "Assigned on save")}" /></div>
                                <div class="ri-field"><label>Version Number</label><input readonly value="${esc(row ? ("v" + (row.versionNumber || 1)) : "v1 (unsaved)")}" /></div>
                                <div class="ri-field"><label>Created By</label><input readonly value="${esc(row ? (row.createdBy || "") : "")}" /></div>
                                <div class="ri-field"><label>Created Date/Time</label><input readonly value="${esc(fmtDT(row && row.createdDateTime))}" /></div>
                                <div class="ri-field"><label>Last Edited By</label><input readonly value="${esc(row ? (row.lastEditedBy || "") : "")}" /></div>
                                <div class="ri-field"><label>Last Edited Date/Time</label><input readonly value="${esc(fmtDT(row && row.lastEditedDateTime))}" /></div>
                            </div>
                        </div>
                    </section>
                </div>
            </div>`;

        syncBadges();
        bindRichToolbar(detailReadOnly);
        bindClaimsInput(el.form.querySelector("[data-key=NoOfClaims]"));
        bindWeekFields();
        el.form.querySelectorAll("input, select, textarea, [contenteditable]").forEach(node => {
            node.addEventListener("input", () => { setDirty(true); if (node.dataset && node.dataset.key === "Status") syncBadges(); });
            node.addEventListener("change", () => { setDirty(true); syncBadges(); });
        });
        setDirty(false);
        if (!modal && window.bootstrap) modal = new bootstrap.Modal(document.getElementById("riModal"));
        modal && modal.show();
    }

    function readForm() {
        const get = key => {
            if (key === "Insights") {
                const ed = el.form.querySelector("#riInsightsEditor");
                return ed ? ed.innerHTML.trim() : "";
            }
            const n = el.form.querySelector(`[data-key="${key}"]`);
            return n ? n.value.trim() : "";
        };
        // Empty strings must become null — System.Text.Json rejects "" for DateTime?
        // and then [FromBody] binds as null → "Missing payload."
        const dateOrNull = v => {
            if (v == null) return null;
            const s = String(v).trim();
            if (!s) return null;
            const iso = isoDate(s);
            return iso || (s.length >= 10 ? s.slice(0, 10) : s);
        };
        const nClaims = parseClaims(get("NoOfClaims"));
        const charge = get("TotalCharge");
        const nCharge = charge === "" ? null : Number(charge);
        const payload = {
            noteId: editing ? editing.noteId : null,
            reportName: ctx.reportName,
            reportRunId: (editing && editing.reportRunId) || ctx.runId || null,
            weekRangeText: (editing && editing.weekRangeText) || ctx.weekText || null,
            weekRangeStart: dateOrNull((editing && editing.weekRangeStart) || ctx.weekStart) || new Date().toISOString().slice(0, 10),
            weekRangeEnd: dateOrNull((editing && editing.weekRangeEnd) || ctx.weekEnd || ctx.weekStart) || new Date().toISOString().slice(0, 10),
            riskCode: riskCode(get("Risk") || "Yellow"),
            responsibleParty: get("ResponsibleParty") || null,
            insights: get("Insights") || null,
            noOfSamples: nClaims,
            totalCharge: Number.isFinite(nCharge) ? nCharge : null,
            dataLink: editing && editing.dataLink ? editing.dataLink : null,
            actionSolution: get("ActionSolution") || null,
            feedbackResponse: get("FeedbackResponse") || null,
            responsibility: get("Responsibility") || null,
            discussionDate: dateOrNull(get("DiscussionDate")),
            eta: dateOrNull(get("ETA")),
            closedDate: dateOrNull(get("ClosedDate")),
            statusCode: statusCode(get("Status") || "Discuss")
        };
        // Fields not on the template keep the values already stored on the insight.
        [["ResponsibleParty", "responsibleParty"], ["NoOfClaims", "noOfSamples"], ["TotalCharge", "totalCharge"],
            ["ActionSolution", "actionSolution"], ["FeedbackResponse", "feedbackResponse"], ["Responsibility", "responsibility"],
            ["DiscussionDate", "discussionDate", true], ["ETA", "eta", true], ["ClosedDate", "closedDate", true]
        ].forEach(([key, prop, isDate]) => {
            if (el.form.querySelector(`[data-key="${key}"]`)) return;
            const prev = editing && editing[prop] != null ? editing[prop] : null;
            payload[prop] = isDate ? dateOrNull(prev) : prev;
        });
        const wf = weekLifecycle ? weekFields() : null;
        if (wf) {
            const ws = wf.start.value, we = wf.end.value || wf.start.value;
            payload.weekRangeStart = ws || null;
            payload.weekRangeEnd = we || null;
            payload.weekRangeText = weekTextFrom(ws, we) || null;
        }
        return payload;
    }

    let dialogEl = null;
    let dialogModal = null;
    const DIALOG_ICONS = { warn: "bi-archive", error: "bi-exclamation-octagon", info: "bi-info-circle" };

    function ensureDialog() {
        if (dialogEl) return dialogEl;
        dialogEl = document.createElement("div");
        dialogEl.className = "modal fade ri-dialog-stack";
        dialogEl.tabIndex = -1;
        dialogEl.setAttribute("aria-hidden", "true");
        dialogEl.innerHTML = `
            <div class="modal-dialog modal-dialog-centered ri-confirm-dialog ri-dialog">
                <div class="modal-content ri-detail-modal ri-confirm-modal">
                    <div class="modal-header ri-detail-head ri-dialog-head">
                        <div class="ri-confirm-icon" aria-hidden="true"><i class="bi"></i></div>
                        <div class="ri-detail-title-block">
                            <div class="ri-detail-title" data-dlg="title"></div>
                            <div class="ri-detail-sub" data-dlg="sub"></div>
                        </div>
                    </div>
                    <div class="modal-body ri-confirm-body" data-dlg="body"></div>
                    <div class="modal-footer ri-detail-footer ri-confirm-footer">
                        <button type="button" class="btn btn-outline-secondary" data-dlg="cancel"></button>
                        <button type="button" class="btn ri-dialog-ok" data-dlg="ok"></button>
                    </div>
                </div>
            </div>`;
        document.body.appendChild(dialogEl);
        dialogEl.addEventListener("shown.bs.modal", () => {
            const backdrops = document.querySelectorAll(".modal-backdrop");
            const last = backdrops[backdrops.length - 1];
            if (last) last.classList.add("ri-dialog-backdrop");
            const ok = dialogEl.querySelector("[data-dlg=ok]");
            ok && ok.focus();
        });
        dialogEl.addEventListener("hidden.bs.modal", () => {
            if (document.querySelector(".modal.show")) document.body.classList.add("modal-open");
        });
        return dialogEl;
    }

    /* Rich replacement for alert/confirm. Resolves true on OK, false on Cancel/close. */
    function riDialog(opts) {
        const o = Object.assign({ tone: "info", title: "", sub: "", bodyHtml: "", okText: "OK", cancelText: null }, opts || {});
        if (!window.bootstrap) {
            const text = stripHtml(o.bodyHtml) || o.title;
            return Promise.resolve(o.cancelText ? confirm(text) : (alert(text), true));
        }
        const node = ensureDialog();
        node.querySelector(".ri-dialog-head").className = "modal-header ri-detail-head ri-dialog-head tone-" + o.tone;
        node.querySelector(".ri-confirm-icon i").className = "bi " + (DIALOG_ICONS[o.tone] || DIALOG_ICONS.info);
        node.querySelector("[data-dlg=title]").textContent = o.title;
        node.querySelector("[data-dlg=sub]").textContent = o.sub;
        node.querySelector("[data-dlg=body]").innerHTML = o.bodyHtml;
        const ok = node.querySelector("[data-dlg=ok]");
        const cancel = node.querySelector("[data-dlg=cancel]");
        ok.textContent = o.okText;
        ok.className = "btn ri-dialog-ok tone-" + o.tone;
        cancel.textContent = o.cancelText || "";
        cancel.hidden = !o.cancelText;
        if (!dialogModal) dialogModal = new bootstrap.Modal(node, { backdrop: "static" });
        return new Promise(resolve => {
            let result = false;
            ok.onclick = () => { result = true; dialogModal.hide(); };
            cancel.onclick = () => dialogModal.hide();
            node.addEventListener("hidden.bs.modal", () => resolve(result), { once: true });
            dialogModal.show();
        });
    }

    const riNotice = (title, message) => riDialog({
        tone: "error", title, sub: "Please correct and try again",
        bodyHtml: `<div class="ri-dialog-msg">${esc(message)}</div>`
    });

    async function save() {
        if (detailReadOnly) return;
        const payload = readForm();
        if (!stripHtml(payload.insights)) { await riNotice("Insights is required", "Enter the insight text before saving."); return; }
        if (payload.statusCode === "Closed" && !payload.closedDate && hasField("ClosedDate")) {
            await riNotice("Closed Date is required", "Closed Date is required when Status is Closed.");
            return;
        }
        if (weekLifecycle && weekFields()) {
            if (!payload.weekRangeStart || !payload.weekRangeEnd) { await riNotice("Week range is required", "Week Range Start and End are required."); return; }
            if (payload.weekRangeEnd < payload.weekRangeStart) { await riNotice("Invalid week range", "Week Range End cannot be before Week Range Start."); return; }
            if (ctx.weekStart && payload.weekRangeEnd < ctx.weekStart) {
                const go = await riDialog({
                    tone: "warn",
                    title: "Save to a previous week range?",
                    sub: "This insight will go straight to Archived Notes",
                    bodyHtml: `
                        <div class="ri-dialog-weeks">
                            <div class="ri-dialog-week old"><span>Insight week range</span><strong>${esc(payload.weekRangeText || "")}</strong></div>
                            <i class="bi bi-arrow-right" aria-hidden="true"></i>
                            <div class="ri-dialog-week cur"><span>Current report week</span><strong>${esc(ctx.weekText || "")}</strong></div>
                        </div>
                        <div class="ri-dialog-msg">The selected week range ends before the current report week, so the insight is saved as <b>Archived</b> (read-only). You can find it under <b>Archived Notes</b>.</div>`,
                    okText: "Save & Archive",
                    cancelText: "Change week range"
                });
                if (!go) return;
            }
        }
        el.save.disabled = true;
        try {
            await postJson(`${apiBase}/Notes/Save?${q({ lab: ctx.lab, report: ctx.reportName })}`, payload);
            modal && modal.hide();
            await loadRows();
            const toArchive = weekLifecycle && ctx.weekStart && payload.weekRangeEnd && payload.weekRangeEnd < ctx.weekStart;
            showAlert(toArchive
                ? `Insight saved for week range ${payload.weekRangeText} and moved to Archived Notes.`
                : "Insight saved. Version was incremented and a revision event was recorded.", "ok");
        } catch (e) { await riNotice("Save failed", e.message); }
        finally { el.save.disabled = false; }
    }

    async function openHistory(noteId) {
        if (!noteId) return;
        const note = rows.find(r => r.noteId === noteId);
        if (el.historyNoteBadge) el.historyNoteBadge.textContent = note ? ("#" + (note.displayNo || note.entryNo || noteId)) : ("Note " + noteId);
        if (el.historySummary) {
            el.historySummary.innerHTML = `
                <div class="ri-ctx-card"><div class="ri-ctx-label">Note</div><div class="ri-ctx-value">${esc(note ? ("#" + (note.displayNo || note.entryNo || noteId)) : noteId)}</div></div>
                <div class="ri-ctx-card"><div class="ri-ctx-label">Current Version</div><div class="ri-ctx-value">${esc(note ? ("v" + (note.versionNumber || 1)) : "—")}</div></div>
                <div class="ri-ctx-card"><div class="ri-ctx-label">Last Edited By</div><div class="ri-ctx-value">${esc(note ? (note.lastEditedBy || "—") : "—")}</div></div>
                <div class="ri-ctx-card"><div class="ri-ctx-label">Last Edited</div><div class="ri-ctx-value">${esc(fmtDT(note && note.lastEditedDateTime) || "—")}</div></div>`;
        }
        el.historyTimeline.innerHTML = `<div class="itm-empty">Loading revision history…</div>`;
        if (modal) modal.hide();
        if (!historyModal && window.bootstrap) historyModal = new bootstrap.Modal(document.getElementById("riHistoryModal"));
        historyModal && historyModal.show();
        try {
            const events = await getJson(`${apiBase}/Notes/Revisions?${q({ lab: ctx.lab, id: noteId })}`);
            if (!events.length) {
                el.historyTimeline.innerHTML = `<div class="itm-empty">No revision events recorded yet.</div>`;
                return;
            }
            el.historyTimeline.innerHTML = events.map(r => {
                const type = (r.eventType || "Edit").toLowerCase();
                const css = type.includes("status") ? "status" : type.includes("risk") ? "risk" : type.includes("archiv") ? "archive" : type.includes("creat") ? "create" : "";
                return `<div class="ri-rev">
                    <div class="ri-rev-dot">${esc((r.eventType || "E").slice(0, 1))}</div>
                    <div class="ri-rev-meta"><strong>${esc(fmtDT(r.eventDateTime) || "—")}</strong>User: ${esc(r.eventUser || "—")}</div>
                    <div class="ri-rev-card">
                        <div class="ri-rev-head"><span class="ri-rev-type ${css}">${esc(r.eventType || "Edit")}</span><span class="ri-version-note">v${esc(r.versionNumber)}</span></div>
                        <div class="ri-rev-change">Revision Made</div>
                        <div>${esc(r.revisionSummary || r.sourceAction || "")}</div>
                    </div>
                </div>`;
            }).join("");
        } catch (e) {
            el.historyTimeline.innerHTML = `<div class="itm-alert error">${esc(e.message)}</div>`;
        }
        const back = document.getElementById("riHistoryBackBtn");
        if (back) {
            back.onclick = () => {
                historyModal && historyModal.hide();
                if (editing && editing.noteId === noteId) modal && modal.show();
                else {
                    const row = rows.find(r => r.noteId === noteId);
                    if (row) openDetail(row, false);
                }
            };
        }
    }

    async function openArchive() {
        const archiveNode = document.getElementById("riArchiveModal");
        if (!archiveModal && window.bootstrap) archiveModal = new bootstrap.Modal(archiveNode);
        const archiveDialog = archiveNode && archiveNode.querySelector(".modal-dialog");
        if (archiveDialog) archiveDialog.classList.toggle("ri-archive-wide", weekLifecycle);
        el.archiveBody.innerHTML = `<div class="itm-empty">Loading archive…</div>`;
        archiveModal && archiveModal.show();
        try {
            const data = await getJson(`${apiBase}/Notes/Archived?${q({ lab: ctx.lab, report: ctx.reportName })}`);
            const s = data.summary || {};
            const archived = data.rows || [];
            const sub = document.getElementById("riArchiveSub");
            if (sub && weekLifecycle) sub.textContent = "Insights from previous week ranges · read-only historical reference";
            if (weekLifecycle) {
                renderArchiveGrid(s, archived);
                return;
            }
            const cards = `<div class="ri-ctx-row">
                <div class="ri-ctx-card"><div class="ri-ctx-label">Total Archived</div><div class="ri-ctx-value">${esc(s.totalArchived || 0)}</div></div>
                <div class="ri-ctx-card"><div class="ri-ctx-label">Red Risk Archived</div><div class="ri-ctx-value">${esc(s.redRiskArchived || 0)}</div></div>
                <div class="ri-ctx-card"><div class="ri-ctx-label">Closed This Month</div><div class="ri-ctx-value">${esc(s.closedThisMonth || 0)}</div></div>
                <div class="ri-ctx-card"><div class="ri-ctx-label">Last Archived</div><div class="ri-ctx-value">${esc(fmtShort(s.lastArchivedDate) || "—")}</div></div>
            </div>
            <div class="ri-lock-note">Archived Notes are read-only. Closed entries older than 4 weeks cannot be edited. Open / WIP / Deferred items older than 4 weeks remain in Active Notes as carry-forward.</div>`;
            const table = archived.length ? `<table class="ri-archive-table"><thead><tr>
                <th>#</th><th>Week Range</th><th>Risk</th><th>Insights</th><th>Status</th><th>Closed</th><th></th>
            </tr></thead><tbody>${archived.map((n, i) => `<tr>
                <td>${i + 1}</td>
                <td>${esc(n.weekRangeText || "")}</td>
                <td><span class="ri-badge risk-${esc(n.riskCode || "Yellow")}">${esc(n.riskCode || "")}</span></td>
                <td class="ri-insights"><div class="ri-insights-html">${sanitizeRichHtml(n.insights || "")}</div></td>
                <td>${esc(n.statusLabel || n.statusCode || "")}</td>
                <td>${esc(fmtShort(n.closedDate))}</td>
                <td class="ri-row-acts">
                    <button type="button" class="btn btn-sm btn-outline-secondary" data-aview="${n.noteId}">View</button>
                </td>
            </tr>`).join("")}</tbody></table>` : `<div class="itm-empty">No archived notes for this report.</div>`;
            el.archiveBody.innerHTML = cards + table;
            bindArchiveActs();
        } catch (e) {
            el.archiveBody.innerHTML = `<div class="itm-alert error">${esc(e.message)}</div>`;
        }
    }

    function bindArchiveActs() {
        el.archiveBody.querySelectorAll("[data-aview]").forEach(btn => {
            btn.onclick = async () => {
                const id = +btn.getAttribute("data-aview");
                try {
                    const note = await getJson(`${apiBase}/Notes/Detail?${q({ lab: ctx.lab, id })}`);
                    archiveModal && archiveModal.hide();
                    openDetail(note, true);
                } catch (e) { await riNotice("Could not open insight", e.message); }
            };
        });
    }

    const archWeekKey = n => ymd(n.weekRangeStart) + "|" + ymd(n.weekRangeEnd);
    const archWeekText = n => n.weekRangeText || weekTextFrom(ymd(n.weekRangeStart), ymd(n.weekRangeEnd)) || "—";

    function renderArchiveGrid(s, archived) {
        const rowsSorted = archived.slice().sort((a, b) =>
            (ymd(b.weekRangeStart) || "").localeCompare(ymd(a.weekRangeStart) || "")
            || (+a.entryNo || 0) - (+b.entryNo || 0)
            || (+a.noteId || 0) - (+b.noteId || 0));
        const weeks = [];
        const seen = new Map();
        rowsSorted.forEach(n => {
            const key = archWeekKey(n);
            if (!seen.has(key)) { const w = { key, text: archWeekText(n), count: 0 }; seen.set(key, w); weeks.push(w); }
            seen.get(key).count++;
        });
        const cards = `<div class="ri-ctx-row">
            <div class="ri-ctx-card"><div class="ri-ctx-label">Total Archived</div><div class="ri-ctx-value">${esc(s.totalArchived || archived.length)}</div></div>
            <div class="ri-ctx-card"><div class="ri-ctx-label">Week Ranges</div><div class="ri-ctx-value">${esc(weeks.length)}</div></div>
            <div class="ri-ctx-card"><div class="ri-ctx-label">Red Risk Archived</div><div class="ri-ctx-value">${esc(s.redRiskArchived || 0)}</div></div>
            <div class="ri-ctx-card"><div class="ri-ctx-label">Last Archived</div><div class="ri-ctx-value">${esc(fmtShort(s.lastArchivedDate) || "—")}</div></div>
        </div>
        <div class="ri-lock-note">Archived Notes are read-only. When a new week range is loaded, insights from previous week ranges move here automatically.</div>`;
        if (!rowsSorted.length) {
            el.archiveBody.innerHTML = cards + `<div class="itm-empty">No archived notes for this report.</div>`;
            return;
        }
        const toolbar = `<div class="ri-arch-toolbar">
            <label for="riArchWeek"><i class="bi bi-calendar-range" aria-hidden="true"></i> Week Range</label>
            <select id="riArchWeek" class="form-select form-select-sm">
                <option value="">All week ranges (${rowsSorted.length})</option>
                ${weeks.map(w => `<option value="${esc(w.key)}">${esc(w.text)} (${w.count})</option>`).join("")}
            </select>
            <span class="ri-arch-count" id="riArchCount"></span>
        </div>`;
        el.archiveBody.innerHTML = cards + toolbar + `<div class="ri-arch-scroll ri-arch-grid" id="riArchGrid"></div>`;
        const select = document.getElementById("riArchWeek");
        const draw = () => {
            const key = select.value;
            const list = key ? rowsSorted.filter(n => archWeekKey(n) === key) : rowsSorted;
            document.getElementById("riArchGrid").innerHTML = archiveTableHtml(list);
            document.getElementById("riArchCount").textContent = `Showing ${list.length} of ${rowsSorted.length} insight(s)`;
            bindArchiveActs();
        };
        select.onchange = draw;
        draw();
    }

    function archiveTableHtml(list) {
        const fields = insightFields(true);
        const head = `<thead><tr>
            <th>#</th><th class="ri-arch-weekcol">Week Range</th>
            ${fields.map(f => `<th${cls(f.th)}>${esc(f.label)}</th>`).join("")}
            <th>Archived On</th><th></th>
        </tr></thead>`;
        const body = list.map((n, i) => `<tr>
                <td>${i + 1}</td>
                <td class="ri-arch-weekcol"><span class="ri-arch-weekpill">${esc(archWeekText(n))}</span></td>
                ${fields.map(f => f.cell(n)).join("")}
                <td class="ri-arch-date">${esc(fmtShort(n.archivedDate))}</td>
                <td class="ri-row-acts">
                    <button type="button" class="btn btn-sm btn-outline-secondary" data-aview="${n.noteId}">View</button>
                </td>
            </tr>`).join("");
        return `<table class="ri-archive-table ri-arch-flat">${head}<tbody>${body}</tbody></table>`;
    }

    function fillTemplates() {
        const prev = el.tpl ? String(el.tpl.value || "") : "";
        el.tpl.innerHTML = templates.map(t => `<option value="${t.templateId}">${esc(t.templateName || t.TemplateName || "")}</option>`).join("")
            || `<option value="">Key Insights & Highlights</option>`;
        if (templates.length >= 1) {
            selectedTpl = templates.find(t => String(t.templateId || t.TemplateId) === prev) || templates[0];
            el.tpl.value = String(selectedTpl.templateId || selectedTpl.TemplateId || "");
        } else {
            selectedTpl = { templateName: "Key Insights & Highlights", columns: [] };
        }
    }

    async function refreshTemplates() {
        try {
            const t = await getJson(`${apiBase}/Notes/Templates?${q({ lab: ctx.lab, report: ctx.reportName })}`);
            templates = t.templates || [];
        } catch { /* keep last known templates */ }
        fillTemplates();
    }

    async function loadRows() {
        const params = { lab: ctx.lab, report: ctx.reportName };
        if (ctx.weekStart && !weekLifecycle) params.weekStart = ctx.weekStart;
        const data = await getJson(`${apiBase}/Notes/Active?${q(params)}`);
        const all = data.rows || [];
        const filtered = !weekLifecycle && (ctx.weekStart || ctx.weekText) ? all.filter(inCurrentWeek) : all;
        if (data.archivedNow > 0) {
            showAlert(`New week range ${data.currentWeekText || ""} loaded: ${data.archivedNow} insight(s) from previous week ranges moved to Archived Notes.`, "info");
        }
        rows = filtered.slice().sort((a, b) => {
            const ea = a.entryNo ?? a.noteId ?? 0;
            const eb = b.entryNo ?? b.noteId ?? 0;
            if (ea !== eb) return ea - eb;
            return (a.noteId || 0) - (b.noteId || 0);
        });
        rows.forEach((n, i) => { n.displayNo = i + 1; });
        renderRows();
    }

    let loadPromise = null;
    let featureAvailable = false;
    let weekLifecycle = false;
    const notEnabledMsg = "Insights are not enabled for this lab yet. Run the NotesInsights SQL scripts (Database\\Shared\\NotesInsights 01-10) on this lab's database.";
    function showPanelLoading() {
        if (el.body) el.body.innerHTML = `<div class="ri-empty"><span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Loading insights…</div>`;
    }
    async function bootSnapshot() {
        if (!snapshotUrl) { el.body.innerHTML = emptyHtml(); return; }
        try {
            const data = await getJson(snapshotUrl);
            templates = data.templates || [];
            fillTemplates();
            rows = (data.rows || []).slice();
            rows.forEach((n, i) => { n.displayNo = i + 1; });
            renderRows();
        } catch (e) {
            showAlert(e.message, "error");
            el.body.innerHTML = emptyHtml();
        }
    }
    async function boot() {
        showPanelLoading();
        if (snapshot) return bootSnapshot();
        try {
            const avail = await getJson(`${apiBase}/Notes/Available?${q({ lab: ctx.lab })}`);
            if (!avail || !avail.available) {
                showAlert(notEnabledMsg, "info");
                el.body.innerHTML = emptyHtml();
                el.add.disabled = true;
                if (el.archiveBtn) el.archiveBtn.disabled = true;
                const importBtn = document.getElementById("riImportBtn");
                if (importBtn) importBtn.disabled = true;
                const templateBtn = document.getElementById("riTemplateBtn");
                if (templateBtn) { templateBtn.classList.add("disabled"); templateBtn.removeAttribute("href"); }
                const toolbarAdd = document.getElementById("riAddInsightBtn");
                if (toolbarAdd) toolbarAdd.disabled = true;
                return;
            }
            featureAvailable = true;
            weekLifecycle = !!avail.weekLifecycle;
            const cw = avail.currentWeek;
            if (weekLifecycle && cw && cw.start) {
                ctx.weekStart = cw.start;
                ctx.weekEnd = cw.end || cw.start;
                ctx.weekText = cw.text || weekTextFrom(cw.start, cw.end);
                if (!ctx.runId && cw.runId) ctx.runId = cw.runId;
            }
            try { lookups = await getJson(`${apiBase}/Notes/Lookups?${q({ lab: ctx.lab })}`); }
            catch { /* defaults in form */ }
            await refreshTemplates();
            await loadRows();
        } catch (e) {
            showAlert(e.message, "error");
            el.body.innerHTML = emptyHtml();
        }
    }
    function ensureLoaded() {
        if (!loadPromise) loadPromise = boot();
        return loadPromise;
    }

    el.tpl.addEventListener("change", () => {
        selectedTpl = templates.find(t => String(t.templateId) === el.tpl.value) || selectedTpl;
        renderRows();
    });
    el.add.addEventListener("click", async () => {
        await ensureLoaded();
        if (!featureAvailable) return;
        await refreshTemplates();
        openDetail(null, false);
    });
    el.save.addEventListener("click", save);
    if (el.deleteConfirmBtn) el.deleteConfirmBtn.addEventListener("click", () => { confirmDeleteInsight(); });
    if (el.archiveBtn) el.archiveBtn.addEventListener("click", () => { ensureLoaded().then(openArchive); });
    if (el.expandBtn) el.expandBtn.addEventListener("click", async () => {
        setOpen(true);
        await ensureLoaded();
        setFloatOpen(true);
    });
    if (el.minimizeBtn) el.minimizeBtn.addEventListener("click", () => setFloatOpen(false));
    (function enableFloatDrag() {
        const win = el.floatWin;
        const head = document.getElementById("riFloatHead");
        if (!win || !head) return;
        let drag = null;
        head.addEventListener("mousedown", function (e) {
            if (e.target.closest("button")) return;
            const r = win.getBoundingClientRect();
            drag = { x: e.clientX - r.left, y: e.clientY - r.top, w: r.width, h: r.height };
            win.style.transform = "none";
            win.style.left = r.left + "px";
            win.style.top = r.top + "px";
            win.style.right = "auto";
            win.style.bottom = "auto";
            win.style.width = r.width + "px";
            e.preventDefault();
        });
        document.addEventListener("mousemove", function (e) {
            if (!drag) return;
            const left = Math.max(8, Math.min(window.innerWidth - drag.w - 8, e.clientX - drag.x));
            const top = Math.max(8, Math.min(window.innerHeight - drag.h - 8, e.clientY - drag.y));
            win.style.left = left + "px";
            win.style.top = top + "px";
        });
        document.addEventListener("mouseup", function () { drag = null; });
    })();
    if (el.historyBtn) el.historyBtn.addEventListener("click", () => {
        if (editing && editing.noteId) openHistory(editing.noteId);
    });
    (function enableImport() {
        const importBtn = document.getElementById("riImportBtn");
        const node = document.getElementById("riImportModal");
        if (!importBtn || !node || readOnly || snapshot) return;
        const templateUrl = `${apiBase}/Notes/ImportTemplate?${q({ lab: ctx.lab, report: ctx.reportName })}`;
        ["riTemplateBtn", "riImportTemplateLink"].forEach(id => {
            const a = document.getElementById(id);
            if (a) a.href = templateUrl;
        });
        const file = document.getElementById("riImportFile");
        const replace = document.getElementById("riImportReplace");
        const note = document.getElementById("riImportModeNote");
        const result = document.getElementById("riImportResult");
        const submit = document.getElementById("riImportSubmit");
        const sub = document.getElementById("riImportSub");
        let importModal = null;

        const showResult = (kind, html) => {
            result.hidden = !html;
            result.className = "mt-3 itm-alert " + kind;
            result.innerHTML = html || "";
        };
        const applyMode = () => {
            note.textContent = replace.checked
                ? "This week's saved insights are deleted, and the workbook's rows take their place."
                : "The rows are added after the insights already saved for this week.";
            submit.classList.toggle("btn-success", !replace.checked);
            submit.classList.toggle("btn-danger", replace.checked);
        };
        replace.addEventListener("change", applyMode);

        const filesBox = document.getElementById("riImportFiles");
        const fileSize = n => n >= 1048576 ? (n / 1048576).toFixed(1) + " MB" : Math.max(1, Math.round(n / 1024)) + " KB";
        async function loadImportFiles() {
            if (!filesBox) return;
            filesBox.innerHTML = `<div class="itm-empty">Loading imported files…</div>`;
            try {
                const data = await getJson(`${apiBase}/Notes/ImportFiles?${q({ lab: ctx.lab, report: ctx.reportName })}`);
                const files = data.files || [];
                if (!files.length) {
                    filesBox.innerHTML = `<div class="itm-empty">No workbooks imported for ${esc(ctx.reportName)} yet.</div>`;
                    return;
                }
                filesBox.innerHTML = `<table class="ri-archive-table ri-import-files-table"><thead><tr>
                    <th>Imported</th><th>File</th><th>Week Range</th><th>Rows</th><th>By</th><th></th>
                </tr></thead><tbody>${files.map(f => `<tr>
                    <td>${esc(fmtDT(f.importedDateTime))}</td>
                    <td>${esc(f.fileName)}<div class="text-muted small">${esc(fileSize(f.fileSize))}</div></td>
                    <td>${esc(f.weekRangeText || "")}</td>
                    <td>${esc(f.rowsImported)} ${f.importMode === "Replace" ? `<div class="text-muted small">replaced ${esc(f.rowsReplaced)}</div>` : ""}</td>
                    <td>${esc(f.importedBy)}</td>
                    <td class="ri-row-acts"><a class="btn btn-sm btn-outline-secondary" href="${apiBase}/Notes/ImportFile?${q({ lab: ctx.lab, id: f.importFileId })}">
                        <i class="bi bi-download" aria-hidden="true"></i> Download</a></td>
                </tr>`).join("")}</tbody></table>`;
            } catch (e) {
                filesBox.innerHTML = `<div class="itm-alert error">${esc(e.message)}</div>`;
            }
        }

        importBtn.addEventListener("click", async () => {
            await ensureLoaded();
            if (!featureAvailable) { showAlert(notEnabledMsg, "info"); return; }
            file.value = "";
            replace.checked = false;
            applyMode();
            showResult("", "");
            submit.disabled = false;
            if (sub) sub.textContent = `Adds the workbook's rows as ${ctx.reportName} insights for ${ctx.weekText || "the current week"}`;
            if (!importModal && window.bootstrap) importModal = new bootstrap.Modal(node);
            importModal && importModal.show();
            loadImportFiles();
        });

        submit.addEventListener("click", async () => {
            const f = file.files && file.files[0];
            if (!f) { showResult("error", "Choose the filled-in Key Insights workbook first."); return; }
            if (replace.checked) {
                const go = await riDialog({
                    tone: "warn", title: "Replace this week's insights?",
                    sub: "The insights saved for this week are deleted",
                    bodyHtml: `<div class="ri-dialog-msg">Every insight saved for <b>${esc(ctx.weekText || "the current week")}</b> is deleted, and the rows in <b>${esc(f.name)}</b> take their place. This cannot be undone.</div>`,
                    okText: "Delete and import", cancelText: "Cancel"
                });
                if (!go) return;
            }
            const body = new FormData();
            body.append("file", f);
            body.append("replace", replace.checked ? "true" : "false");
            if (ctx.weekStart) body.append("weekStart", ctx.weekStart);
            if (ctx.weekEnd) body.append("weekEnd", ctx.weekEnd);
            if (ctx.weekText) body.append("weekText", ctx.weekText);
            if (ctx.runId) body.append("runId", ctx.runId);
            submit.disabled = true;
            showResult("info", `<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Checking and importing ${esc(f.name)}…`);
            try {
                const res = await fetch(`${apiBase}/Notes/Import?${q({ lab: ctx.lab, report: ctx.reportName })}`, {
                    method: "POST", headers: { Accept: "application/json", RequestVerificationToken: ctx.token }, body
                });
                let data = null;
                try { data = await res.json(); } catch { /* not JSON */ }
                if (!res.ok) {
                    const list = data && data.errors && data.errors.length
                        ? `<ul class="mb-0 mt-1">${data.errors.slice(0, 50).map(e => `<li>${esc(e)}</li>`).join("")}</ul>${data.errors.length > 50 ? `<div>…and ${data.errors.length - 50} more.</div>` : ""}`
                        : "";
                    showResult("error", `<strong>${esc((data && data.error) || ("Import failed (" + res.status + ")"))}</strong>${list}`);
                    return;
                }
                await loadRows();
                const parts = [`${data.imported} insight(s) imported for ${data.weekText || ctx.weekText || "the current week"}`];
                if (data.replaced) parts.push(`${data.replaced} previous insight(s) replaced`);
                if (data.failed) parts.push(`${data.failed} row(s) could not be saved: ${(data.errors || []).join("; ")}`);
                if (data.warnings && data.warnings.length) parts.push(data.warnings.join(" "));
                importModal && importModal.hide();
                showAlert(parts.join(". ") + ".", data.failed ? "error" : "ok");
                setOpen(true);
            } catch (e) {
                showResult("error", esc(e.message || "Import failed."));
            } finally {
                submit.disabled = false;
            }
        });
    })();

    const extraAdd = document.getElementById("riAddInsightBtn");
    if (extraAdd && snapshot) extraAdd.hidden = true;
    else if (extraAdd) extraAdd.addEventListener("click", async () => {
        setOpen(true);
        root.scrollIntoView({ behavior: "smooth", block: "start" });
        await ensureLoaded();
        if (!featureAvailable) { showAlert(notEnabledMsg, "info"); return; }
        await refreshTemplates();
        openDetail(null, false);
    });

    (function ensureCollapseChrome() {
        if (document.getElementById("riToggle")) return;
        const head = root.querySelector(".ri-head");
        if (!head) return;
        const first = head.firstElementChild;
        const wrap = document.createElement("div");
        wrap.className = "ri-head-main";
        const btn = document.createElement("button");
        btn.type = "button";
        btn.className = "ri-toggle";
        btn.id = "riToggle";
        btn.setAttribute("aria-expanded", "true");
        btn.setAttribute("aria-controls", "riCollapse");
        btn.title = "Open / close insights";
        btn.innerHTML = '<i class="bi bi-chevron-down ri-toggle-icon" aria-hidden="true"></i>';
        wrap.appendChild(btn);
        if (first) wrap.appendChild(first);
        head.insertBefore(wrap, head.firstChild);

        const collapse = document.createElement("div");
        collapse.id = "riCollapse";
        collapse.className = "ri-collapse";
        const alertEl = document.getElementById("riAlert");
        const bodyEl = document.getElementById("riBody");
        if (alertEl) collapse.appendChild(alertEl);
        if (bodyEl) collapse.appendChild(bodyEl);
        root.appendChild(collapse);
    })();

    const toggle = document.getElementById("riToggle");
    function setOpen(open) {
        root.classList.toggle("ri-collapsed", !open);
        if (toggle) toggle.setAttribute("aria-expanded", open ? "true" : "false");
        if (open) {
            // A snapshot's templates came with its rows; the live list is not asked for.
            ensureLoaded().then(() => snapshot ? renderRows() : refreshTemplates().then(() => renderRows()));
        }
    }
    setOpen(readOnly);
    if (toggle) {
        toggle.addEventListener("click", () => setOpen(root.classList.contains("ri-collapsed")));
    }
    const headMain = root.querySelector(".ri-head-main h3");
    if (headMain) {
        headMain.style.cursor = "pointer";
        headMain.addEventListener("click", () => setOpen(root.classList.contains("ri-collapsed")));
    }
})();
